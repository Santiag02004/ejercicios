﻿using ejercicio2;

Console.WriteLine("Ingrese un número:");
int n = int.Parse(Console.ReadLine());
Series.Mostrar(n);
