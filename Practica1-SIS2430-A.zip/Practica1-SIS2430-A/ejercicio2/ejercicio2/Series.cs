﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio2
{
    internal class Series
    {
        public static string GenerarSerie(int n, Func<int, string> serieFunction)
        {
            return serieFunction(n);
        }

        public static string Serie1(int n)
        {
            string serie = "";
            int num = 1;
            for (int i = 1; i <= n; i++)
            {
                num *= i;
                serie += num + ",";
            }
            return serie;
        }

        public static string Serie2(int n)
        {
            string serie = "";
            for (int i = 1; i <= n; i++)
            {
                if (i % 3 == 0)
                    serie += i + ",";
            }
            return serie;
        }

        public static string Serie3(int n)
        {
            string serie = "";
            for (int i = 1; i <= n; i++)
            {
                if (i % 6 == 0)
                    serie += i + ",";
            }
            return serie;
        }

        public static void Mostrar(int n)
        {
            Console.WriteLine("Serie1: " + GenerarSerie(n, Serie1));
            Console.WriteLine("Serie2: " + GenerarSerie(n * 3, Serie2));
            Console.WriteLine("Serie3: " + GenerarSerie(n * 5, Serie3));
        }
    }
}