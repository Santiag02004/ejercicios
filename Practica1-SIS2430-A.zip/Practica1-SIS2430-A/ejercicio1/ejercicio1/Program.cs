﻿
Console.WriteLine("Ingrese un numero: ");
int numero = Convert.ToInt32(Console.ReadLine());
NumerosUtilidades.MostrarParteLiteral(numero);

public static class NumerosUtilidades
{
    private static string[] unidades = { "", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve" };
    private static string[] especiales = { "diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve" };
    private static string[] decenas = { "", "diez", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa" };
    private static string[] centenas = { "", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos" };

    public static void MostrarParteLiteral(int numero)
    {
        if (numero == 0)
        {
            Console.WriteLine("cero");
            return;
        }
        string literal = "";
  
        if (numero >= 100)
        {
            literal += centenas[numero / 100] + " ";
            numero %= 100;
        }
     
        if (numero >= 10 && numero <= 19)
        {
            literal += especiales[numero - 10];
            Console.WriteLine(literal);
            return;
        }

        if (numero >= 20)
        {
            literal += decenas[numero / 10] + " ";
            numero %= 10;
        }

        if (numero > 0)
        {
            literal += unidades[numero];
        }
        Console.WriteLine("\nParte literal: ");
        Console.WriteLine(literal);
    }
}
