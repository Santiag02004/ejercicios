﻿using ejercicio5.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio5.Controller
{
    internal class PcNueva_controller
    {
        List<NuevaPc> nuevas = new List<NuevaPc>();




        public void Agregar_PC()
        {
            nuevas.Add(new NuevaPc()
            {
                Ram = 16,
                Pantalla = 1080,
                Marca = "HP",
                Modelo = "Pavilon 5",
                TipoSistema = "x64 bits",
                Almacenamiento = 1024,
                Precio = 6500,
                FechaIngreso = new DateTime(2023, 05, 10)
            });

            nuevas.Add(new NuevaPc()
            {
                Ram = 8,
                Pantalla = 1080,
                Marca = "Lenovo",
                Modelo = "Flex 5",
                TipoSistema = "x64 bits",
                Almacenamiento = 2048,
                Precio = 6000,
                FechaIngreso = new DateTime(2022, 01, 18)
            });
            nuevas.Add(new NuevaPc()
            {
                Ram = 16,
                Pantalla = 1080,
                Marca = "Lenovo",
                Modelo = "Legion",
                TipoSistema = "x64 bits",
                Almacenamiento = 2048,
                Precio = 8500,
                FechaIngreso = new DateTime(2020, 10, 01)
            });
            nuevas.Add(new NuevaPc()
            {
                Ram = 32,
                Pantalla = 3100,
                Marca = "Acer",
                Modelo = "Nitro 5",
                TipoSistema = "x64 bits",
                Almacenamiento = 1024,
                Precio = 10000,
                FechaIngreso = new DateTime(2023, 12, 25)
            });
            nuevas.Add(new NuevaPc()
            {
                Ram = 8,
                Pantalla = 3100,
                Marca = "Acer",
                Modelo = "Nitro 5",
                TipoSistema = "x64 bits",
                Almacenamiento = 1024,
                Precio = 10000,
                FechaIngreso = new DateTime(2023, 12, 25)
            });
            nuevas.Add(new NuevaPc()
            {
                Ram = 32,
                Pantalla = 2015,
                Marca = "Acer",
                Modelo = "Nitro 4",
                TipoSistema = "x64 bits",
                Almacenamiento = 2048,
                Precio = 9000,
                FechaIngreso = new DateTime(2022, 08, 15)
            });
            nuevas.Add(new NuevaPc()
            {
                Ram = 16,
                Pantalla = 1080,
                Marca = "Lenovo",
                Modelo = "Ideapad 5",
                TipoSistema = "x64 bits",
                Almacenamiento = 500,
                Precio = 5500,
                FechaIngreso = new DateTime(2023, 12, 25)
            });
            nuevas.Add(new NuevaPc()
            {
                Ram = 16,
                Pantalla = 3100,
                Marca = "Lenovo",
                Modelo = "Ideapad 3 Gaming",
                TipoSistema = "x64 bits",
                Almacenamiento = 500,
                Precio = 6000,
                FechaIngreso = new DateTime(2021, 10, 20)
            });
            nuevas.Add(new NuevaPc()
            {
                Ram = 32,
                Pantalla = 3100,
                Marca = "HP",
                Modelo = "Victus",
                TipoSistema = "x64 bits",
                Almacenamiento = 2024,
                Precio = 6500,
                FechaIngreso = new DateTime(2023, 06, 06)
            });
            nuevas.Add(new NuevaPc()
            {
                Ram = 32,
                Pantalla = 3100,
                Marca = "HP",
                Modelo = "Spectre",
                TipoSistema = "x64 bits",
                Almacenamiento = 3024,
                Precio = 14000,
                FechaIngreso = new DateTime(2023, 12, 01)
            });
        }
        public void ModificarPC(string modelo, int nuevoAlmacenamiento, string nuevoModelo)
        {
            foreach (var pc in nuevas)
            {
                if (pc.Modelo == modelo)
                {
                    pc.Almacenamiento = nuevoAlmacenamiento;
                    pc.Modelo = nuevoModelo;
                    Console.WriteLine($"PC con modelo '{modelo}' modificada correctamente.");
                    return;
                }
            }
            Console.WriteLine($"No se encontró ninguna PC con el modelo '{modelo}'.");
        }
        public void PromPc()
        {
            decimal sumaPrecios = nuevas.Sum(pc => pc.Precio);

            decimal totalPcs = nuevas.Count;

            decimal promedio = totalPcs > 0 ? sumaPrecios / totalPcs : 0;

            Console.WriteLine($"El promedio es: {promedio}");

        }
        public void VerRam()
        {
            var pcsCon16GBRam = nuevas.Where(pc => pc.Ram == 16)
                                       .Select(pc => new { Marca = pc.Marca, Modelo = pc.Modelo });

            Console.WriteLine("PCs con 16 GB de RAM:");
            foreach (var pc in pcsCon16GBRam)
            {
                Console.WriteLine($"Marca: {pc.Marca}, Modelo: {pc.Modelo}");
            }
        }
        public void HpList()
        {
            var hpPcs = from pc in nuevas
                        where pc.Marca == "HP" && pc.TipoSistema == "x64 bits" && pc.FechaIngreso.Year == 2023
                        select pc;

            Console.WriteLine("PCs de Marca HP con sistema de 64 bits ingresadas en 2023:");
            foreach (var pc in hpPcs)
            {
                Console.WriteLine($"Marca: {pc.Marca}, Modelo: {pc.Modelo}, Tipo de sistema: {pc.TipoSistema}, Fecha de Ingreso: {pc.FechaIngreso}");
            }
        }

        public void MonthPc()
        {
            DateTime fechaActual = DateTime.Now;

            var pcsMasDeDosMeses = from pc in nuevas
                                   where (fechaActual - pc.FechaIngreso).TotalDays > 60 // 2 meses = 60 días
                                   select pc;

            Console.WriteLine("PCs que han estado en stock durante más de 2 meses:");
            foreach (var pc in pcsMasDeDosMeses)
            {
                Console.WriteLine($"Marca: {pc.Marca}, Modelo: {pc.Modelo}, Fecha de Ingreso: {pc.FechaIngreso}");
            }
        }
        public void OrdenarPantallaModeloLinq()
        {
            var pcsOrdenadas = from pc in nuevas
                               orderby pc.Pantalla, pc.Modelo
                               select pc;

            Console.WriteLine("PCs ordenadas por tipo de pantalla y modelo:");
            foreach (var pc in pcsOrdenadas)
            {
                Console.WriteLine($"Tipo de pantalla: {pc.Pantalla}, Modelo: {pc.Modelo}");
            }
        }
        public void OrdenarPantallaModeloLambda()
        {
            var pcsOrdenadas = nuevas.OrderBy(pc => pc.Pantalla).ThenBy(pc => pc.Modelo);

            Console.WriteLine("PCs ordenadas por tipo de pantalla y modelo:");
            foreach (var pc in pcsOrdenadas)
            {
                Console.WriteLine($"Tipo de pantalla: {pc.Pantalla}, Modelo: {pc.Modelo}");
            }
        }

    }
}
