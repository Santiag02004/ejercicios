﻿using ejercicio5.Controller;

int op = 0;
PcNueva_controller pc = new PcNueva_controller();
pc.Agregar_PC();
do{
    Console.WriteLine("\n   OPCIONES   \n");
    Console.WriteLine("1.-Modificar\n2.-Promedio\n3.-Ver ram\n4.-Mostrar HP\n5.-Meses en Stock\n6.-Ordenar (conLQ)\n7.-Ordenar (Lambda)\n8.-Salir");
    Console.WriteLine("--------------------------------------");
    op = int.Parse(Console.ReadLine());
    Console.WriteLine("--------------------------------------");
    switch (op)
    {
        case 1:
            Console.WriteLine("Ingrese el modelo de la PC a modificar:");
            string modelo = Console.ReadLine();
            Console.WriteLine("Ingrese el nuevo almacenamiento:");
            int nuevoAlmacenamiento = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el nuevo modelo:");
            string nuevoModelo = Console.ReadLine();

            pc.ModificarPC(modelo, nuevoAlmacenamiento, nuevoModelo);
            break;
        case 2:
            pc.PromPc();
            break;
        case 3:
            pc.VerRam(); 
            break;
        case 4:
            pc.HpList();
            break;
        case 5:
            pc.MonthPc();          
            break;
        case 6:
            pc.OrdenarPantallaModeloLinq();
            break;
        case 7:
            pc.OrdenarPantallaModeloLambda();
            break;
    }
} while (op!=8);
