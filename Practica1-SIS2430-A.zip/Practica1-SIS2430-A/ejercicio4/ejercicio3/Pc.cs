﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio3
{
    internal class Pc
    {
        public int Ram { get; set; }
        public double Pantalla { get; set; }
        public string? Marca { get; set; }
        public string? Modelo { get; set; }
        public string? TipoSistema { get; set; }
        public int Almacenamiento { get; set; }
        public virtual void mostrarPC()
        {
            Console.WriteLine("\n---------------------------------------------------");
            Console.WriteLine("CARACTERISTICAS DEL EQUIPO");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine($"Ram: {Ram}GB\nMarca: {Marca}\nModelo: {Modelo}\nTipo de sistema: {TipoSistema}\nAlmacenamiento {Almacenamiento}GB\n");
            Console.WriteLine("---------------------------------------------------");
        }
        public Pc() { }
    }
}
