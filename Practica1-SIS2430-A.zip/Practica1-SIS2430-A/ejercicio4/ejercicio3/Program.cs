﻿using ejercicio3;
int op = 0;
do {
    Console.WriteLine("\nELIJA UNA OPCION");
    Console.WriteLine("1.-Pc\n2.-Nueva pc\n3.-Reparacion de pc\n4.-Salir");
    Console.WriteLine("---------------------------------------------------");
    op = int.Parse(Console.ReadLine());
    Console.WriteLine("---------------------------------------------------");
    switch (op) 
    { 
        case 1:
            Pc pc = new Pc();

            Console.Write("Ingrese la ram de la pc: ");
            pc.Ram = int.Parse(Console.ReadLine());
            Console.Write("Ingrese la pantalla de la pc: ");
            pc.Pantalla=double.Parse(Console.ReadLine());
            Console.Write("Ingrese la marca de la pc: ");
            pc.Marca=Console.ReadLine();
            Console.Write("Ingrese el modelo de la pc: ");
            pc.Modelo=Console.ReadLine();
            Console.Write("Ingrese el tipo de sistema de la pc: ");
            pc.TipoSistema=Console.ReadLine();
            Console.Write("Ingrese el almacenamiento de la pc: ");
            pc.Almacenamiento=int.Parse(Console.ReadLine());

            pc.mostrarPC();
            break;
        case 2:
            PcNueva pcn = new PcNueva();

            Console.Write("Ingrese la ram de la pc: ");
            pcn.Ram = int.Parse(Console.ReadLine());
            Console.Write("Ingrese la pantalla de la pc: ");
            pcn.Pantalla = double.Parse(Console.ReadLine());
            Console.Write("Ingrese la marca de la pc: ");
            pcn.Marca = Console.ReadLine();
            Console.Write("Ingrese el modelo de la pc: ");
            pcn.Modelo = Console.ReadLine();
            Console.Write("Ingrese el tipo de sistema de la pc: ");
            pcn.TipoSistema = Console.ReadLine();
            Console.Write("Ingrese el almacenamiento de la pc: ");
            pcn.Almacenamiento = int.Parse(Console.ReadLine());
            Console.Write("Ingrese el precio de la nueva pc: ");
            pcn.Precio =int.Parse(Console.ReadLine());
            Console.Write("Ingrese la fecha de ingreso: ");
            pcn.FechaIngreso=DateTime.Parse(Console.ReadLine());

            pcn.mostrarPC();
            break;
        case 3:
            PcReparacion pcr = new PcReparacion();

            Console.Write("Ingrese la ram de la pc: ");
            pcr.Ram = int.Parse(Console.ReadLine());
            Console.Write("Ingrese la pantalla de la pc: ");
            pcr.Pantalla = double.Parse(Console.ReadLine());
            Console.Write("Ingrese la marca de la pc: ");
            pcr.Marca = Console.ReadLine();
            Console.Write("Ingrese el modelo de la pc: ");
            pcr.Modelo = Console.ReadLine();
            Console.Write("Ingrese el tipo de sistema de la pc: ");
            pcr.TipoSistema = Console.ReadLine();
            Console.Write("Ingrese el almacenamiento de la pc: ");
            pcr.Almacenamiento = int.Parse(Console.ReadLine());
            Console.Write("Ingrese la causa: ");
            pcr.Causa = Console.ReadLine();
            Console.Write("Ingrese la la fecha defecto: ");
            pcr.FechaDefecto=DateTime.Parse(Console.ReadLine());

            pcr.mostrarPC();
            break;
    }
} while (op!=4);