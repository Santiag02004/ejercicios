﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio3
{
    internal class PcReparacion: Pc
    {
        public string Causa { get; set; }
        public DateTime FechaDefecto { get; set; }
        public override void mostrarPC()
        {
            Console.WriteLine("\n---------------------------------------------------");
            Console.WriteLine("CARACTERISTICAS DEL EQUIPO");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine($"Ram: {Ram}GB\nMarca: {Marca}\nModelo: {Modelo}\nTipo de sistema: {TipoSistema}\nAlmacenamiento {Almacenamiento}GB\nCausa: {Causa}\n fecha defecto: {FechaDefecto}");
            Console.WriteLine("---------------------------------------------------");
        }
    }
}
