﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio3
{
    internal class PcNueva:Pc
    {
        public decimal Precio { get; set; }
        public DateTime FechaIngreso { get; set; }
       
        public override void mostrarPC() 
        {
            Console.WriteLine("\n---------------------------------------------------");
            Console.WriteLine("CARACTERISTICAS DEL EQUIPO");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine($"Ram: {Ram}GB\nMarca: {Marca}\nModelo: {Modelo}\nTipo de sistema: {TipoSistema}\nAlmacenamiento {Almacenamiento}GB\nPrecio: {Precio}Bs\nFecha de Ingreso: {FechaIngreso}");
            Console.WriteLine("---------------------------------------------------");
        }
    }
}
