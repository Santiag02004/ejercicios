﻿List<int> lista_Enteros = new List<int>();

lista_Enteros.Add(15);
lista_Enteros.Add(50);
lista_Enteros.Add(1);
lista_Enteros.Add(8);
lista_Enteros.Add(10);
lista_Enteros.Add(6);
lista_Enteros.Add(2);
lista_Enteros.Add(7);
lista_Enteros.Add(100);
lista_Enteros.Add(3);
Console.WriteLine("ordenar por Lambda: ");
OrdenarEL(lista_Enteros);
Console.WriteLine("\nOrdenar por consultas LinQ: ");
OrdenarCLQ(lista_Enteros);
Console.WriteLine($"\n\nMayor: {lista_Enteros.Max()}");
Console.WriteLine($"Menor: {lista_Enteros.Min()}");
void OrdenarEL(List<int> lista_Enteros)
{
    // Expreciones Lambda
    var listaOrdenada = lista_Enteros.OrderBy(x => x).ToList();
    foreach (var item in listaOrdenada)
    {
        Console.Write(item + "  ");
    }
}

void OrdenarCLQ(List<int> listaCLQ)
{
    //consultas LQ
    //var nombre = from x in lista
    //             where x>5
    //             select x.nombre (Cuando quieres todos los atributos, solo poner su nombre
    //                              y solo quieres ciertos campos poner x.Atributo)
    var listaOrdenadaCLQ = from num in listaCLQ
                           orderby num
                           select num;

    foreach (var itemN in listaOrdenadaCLQ)
    {
        Console.Write(itemN + "  ");
    }
}